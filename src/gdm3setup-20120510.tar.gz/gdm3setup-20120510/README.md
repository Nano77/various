GDM3setup
=========

A GUI to setting GDM3

Nano77 <nanoarch77@gmail.com>



Archlinux
---------

GDM3setup is in AUR, you can install : 

- With an AUR helper like yaourt : `yaourt -S gdm3setup`

- Or without an AUR Helper :

	Get the PKGBUILD from AUR : `wget http://aur.archlinux.org/packages/gdm3setup/PKGBUILD`

	and run `makepkg -i`


Fedora
------
You can use the RPM package from : [https://github.com/Nano77/various/tree/master/rpm]()


OpenSUSE
--------
You can use the RPM package from : [https://github.com/Nano77/various/tree/master/rpm]()


Ubuntu (Oneiric Ocelot)
-----------------------
You can use the DEB package from : [https://github.com/Nano77/various/tree/master/deb]()

Debian (wheezy)
------
You can use the "debian" DEB package from : [https://github.com/Nano77/various/tree/master/deb]()


